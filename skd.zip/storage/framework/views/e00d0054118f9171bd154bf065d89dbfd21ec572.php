<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <h3>welcome</h3>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\skd\resources\views/home.blade.php ENDPATH**/ ?>