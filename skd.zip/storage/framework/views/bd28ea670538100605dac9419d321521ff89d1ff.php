
<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <?php echo $__env->make('frontend/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-6 mx-auto py-5">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        Penilaian Nilai Ujian
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <tbody>
                                <tr>
                                    <th style="width:40%">TWK</th>
                                    <td style="width:20%">:</td>
                                    <th style="width:40%"><?php echo e($nilai['twk']); ?></th>
                                </tr>
                                <tr>
                                    <th>TIU</th>
                                    <td>:</td>
                                    <th><?php echo e($nilai['tiu']); ?></th>
                                </tr>
                                <tr>
                                    <th>TKP</th>
                                    <td>:</td>
                                    <th><?php echo e($nilai['tkp']); ?></th>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer">
                        <a class="btn btn-primary btn-sm text-white" href="/">Beranda</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\skd\resources\views/frontend/page/ujian/nilaiskor.blade.php ENDPATH**/ ?>