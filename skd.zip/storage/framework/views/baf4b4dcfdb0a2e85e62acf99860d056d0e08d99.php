
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Soal</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#">MEDIATAMA CAT</a></li>
                    <li class="breadcrumb-item active">Soal</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <!-- Default box -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title"><button class="btn btn-primary btn-sm text-white"
                                onclick="window.history.back();"><i class="fa fa-arrow-left"></i> Back</button></h3>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip"
                                title="Collapse">
                                <i class="fas fa-minus"></i></button>
                            <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip"
                                title="Remove">
                                <i class="fas fa-times"></i></button>
                        </div>
                    </div>
                    <div class="card-body">
                        <form class="form-horizontal" action="<?php echo e(route($url, $soal->soal_id ?? null)); ?>"
                            method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php if(isset($soal)): ?>
                            <?php echo method_field('put'); ?>
                            <?php endif; ?>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Kategori Soal</label>
                                            <select
                                                class="custom-select select2bs4 <?php $__errorArgs = ['soal_kategori_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="soal_kategori_id" id="soal_kategori_id">
                                                <option value="">-- Pilih --</option>
                                                <?php $__currentLoopData = $kategori_soal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ktg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($ktg->kategori_id); ?>"><?php echo e($ktg->kategori_soal); ?>

                                                </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>

                                            <?php if( old('soal_kategori_id') != '' ): ?>
                                            <script>
                                                document.getElementById('soal_kategori_id').value =
                                                    "<?php echo e(old('soal_kategori_id')); ?>"

                                            </script>
                                            <?php endif; ?>
                                            <?php if(isset($soal)): ?>
                                            <script>
                                                document.getElementById('soal_kategori_id').value =
                                                    '<?php echo $soal->soal_kategori_id ?>'
                                            </script>
                                            <?php endif; ?>
                                            <?php $__errorArgs = ['soal_kategori_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Tipe Soal</label>
                                            <select
                                                class="custom-select select2bs4 <?php $__errorArgs = ['soal_ujian_tipe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="soal_ujian_tipe" id="soal_ujian_tipe">
                                                <option value="">-- Pilih --</option>
                                                <option value="text">Text</option>
                                                <option value="file">Foto</option>
                                            </select>

                                            <?php if( old('soal_ujian_tipe') != '' ): ?>
                                            <script>
                                                document.getElementById('soal_ujian_tipe').value =
                                                    "<?php echo e(old('soal_ujian_tipe')); ?>"
                                            </script>
                                            <?php endif; ?>
                                            <?php if(isset($soal)): ?>
                                            <script>
                                                document.getElementById('soal_ujian_tipe').value =
                                                    '<?php echo $soal->soal_ujian_tipe ?>'
                                            </script>
                                            <?php endif; ?>
                                            <?php $__errorArgs = ['soal_ujian_tipe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Tipe Jawaban</label>
                                            <select
                                                class="custom-select select2bs4 <?php $__errorArgs = ['soal_pilihan_tipe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="soal_pilihan_tipe" id="soal_pilihan_tipe">
                                                <option value="">-- Pilih --</option>
                                                <option value="text">Text</option>
                                                <option value="file">Foto</option>
                                                <option value="audio">Audio</option>
                                            </select>

                                            <?php if( old('soal_pilihan_tipe') != '' ): ?>
                                            <script>
                                                document.getElementById('soal_pilihan_tipe').value =
                                                    "<?php echo e(old('soal_pilihan_tipe')); ?>"

                                            </script>
                                            <?php endif; ?>
                                            <?php if(isset($soal)): ?>
                                            <script>
                                                document.getElementById('soal_pilihan_tipe').value =
                                                    '<?php echo $soal->soal_pilihan_tipe ?>'
                                            </script>
                                            <?php endif; ?>
                                            <?php $__errorArgs = ['soal_pilihan_tipe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-12" id="soal_ujian_div">

                                    </div>
                                    <div class="col-md-12" id="soal_jawaban_div">

                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary">Save</button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer">

                    </div>
                    <!-- /.card-footer-->
                </div>
                <!-- /.card -->
            </div>
        </div>
    </div>
</section>

<script>

    // cari data submapel
    $('#soal_mapel_id').change(function (e) { 
        e.preventDefault();
        let id = this.value
        axios.post('<?php echo e(route("soal.cariSubmapel")); ?>', {
            'id' : id
        }).then(function (res) { 
            var data = res.data.data;
            document.getElementById('soal_submapel_id').innerHTML = "<option value='0'>-- Pilih --</option>";
            for(var x = 0; x < data.length; x++)
            {
                document.getElementById("soal_submapel_id").innerHTML += "<option value='" + data[x].submapel_id + "'>" + data[x].submapel_kategori + "</option>";
            }
        }).catch(function (err) { 
            console.log(err);
        })
    });

    // tampilkan form soal
    $('#soal_ujian_tipe').change(function (e) { 
        e.preventDefault();
        var tipe = this.value;
        document.getElementById("soal_ujian_div").innerHTML = '';
        if(tipe == 'text'){
            document.getElementById("soal_ujian_div").innerHTML += `
            <div class="form-group"> 
                <label>Soal</label>
                <textarea class="form-control textarea <?php $__errorArgs = ['soal_ujian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_ujian" id="soal_ujian" rows="10"><?php echo e(old('soal_ujian')  ??  $soal->soal_ujian ?? ''); ?></textarea>
            </div>
            <?php $__errorArgs = ['soal_ujian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>`;

            $('.textarea').summernote({
                height: 200
            });
        }else if(tipe == 'file'){
            document.getElementById("soal_ujian_div").innerHTML += `
            <?php if(isset($soal)): ?> 
            <img src="<?php echo e(asset('images/soal/' .  $soal->soal_ujian)); ?>" style="height: 250px;">
            <?php endif; ?>
            <div class="form-group">
                <label>Soal</label>
                <input type="file" class="form-control <?php $__errorArgs = ['soal_ujian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_ujian" id="soal_ujian" value="<?php echo e(old('soal_ujian')  ?? ''); ?>">
            </div>
            <?php $__errorArgs = ['soal_ujian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>`;
        }else if(tipe == 'audio'){
            document.getElementById("soal_ujian_div").innerHTML += `
            <?php if(isset($soal)): ?> 
            <img src="<?php echo e(asset('upload/audio/' .  $soal->soal_ujian)); ?>" style="height: 250px;">
            <?php endif; ?>
            <div class="form-group">
                <label>Soal</label>
                <input type="file" class="form-control <?php $__errorArgs = ['soal_ujian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_ujian" id="soal_ujian" value="<?php echo e(old('soal_ujian')  ?? ''); ?>">
            </div>
            <?php $__errorArgs = ['soal_ujian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>`;
        }
    });

    // tampilkan form jawaban
    $('#soal_pilihan_tipe').change(function (e) { 
        e.preventDefault();
        var tipe = this.value;
        document.getElementById("soal_jawaban_div").innerHTML = '';
        if(tipe == 'text'){
            document.getElementById("soal_jawaban_div").innerHTML += ` 

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Pilihan A</label>
                        <textarea class="form-control <?php $__errorArgs = ['soal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_a" id="soal_a" rows="10"><?php echo e(old('soal_a')  ?? $soal->soal_a ?? ''); ?></textarea>
                    </div>
                    <?php $__errorArgs = ['soal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Pilihan B</label>
                        <textarea class="form-control <?php $__errorArgs = ['soal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_b" id="soal_b" rows="10"><?php echo e(old('soal_b')  ?? $soal->soal_b ?? ''); ?></textarea>
                    </div>
                    <?php $__errorArgs = ['soal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Pilihan C</label>
                        <textarea class="form-control <?php $__errorArgs = ['soal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_c" id="soal_c" rows="10"><?php echo e(old('soal_c')  ?? $soal->soal_c ?? ''); ?></textarea>
                    </div>
                    <?php $__errorArgs = ['soal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Pilihan D</label>
                        <textarea class="form-control <?php $__errorArgs = ['soal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_d" id="soal_d" rows="10"><?php echo e(old('soal_d')  ?? $soal->soal_d ?? ''); ?></textarea>
                    </div>
                    <?php $__errorArgs = ['soal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Pilihan E</label>
                        <textarea class="form-control <?php $__errorArgs = ['soal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_e" id="soal_e" rows="10"><?php echo e(old('soal_e')  ?? $soal->soal_e ?? ''); ?></textarea>
                    </div>
                    <?php $__errorArgs = ['soal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Kunci Jawaban</label>
                        <table class="table table-bordered">
                            <tr>
                                <td>A</td>
                                <td>
                                    <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_a" value="<?php echo e(old('skorsoal_a')  ?? $soal->skorsoal_a ?? ''); ?>">
                                    <?php $__errorArgs = ['skorsoal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>

                            </tr>
                            <tr>
                                <td>B</td>
                                <td>
                                    <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_b" value="<?php echo e(old('skorsoal_b')  ?? $soal->skorsoal_b ?? ''); ?>">
                                    <?php $__errorArgs = ['skorsoal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                            </tr>
                            <tr>
                                <td>C</td>
                                <td>
                                    <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_c"  value="<?php echo e(old('skorsoal_c')  ?? $soal->skorsoal_c ?? ''); ?>">
                                    <?php $__errorArgs = ['skorsoal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                            </tr>
                            <tr>
                                <td>D</td>
                                <td>
                                    <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_d" value="<?php echo e(old('skorsoal_d')  ?? $soal->skorsoal_d ?? ''); ?>">
                                    <?php $__errorArgs = ['skorsoal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                            </tr>
                            <tr>
                                <td>E</td>
                                <td>
                                    <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_e" value="<?php echo e(old('skorsoal_e')  ?? $soal->skorsoal_e ?? ''); ?>">
                                    <?php $__errorArgs = ['skorsoal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>      
            `;

            $('.textarea').summernote({
                height: 200
            });
            $('.number').keyup(function (e) { 
                this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');
            });
        }else if(tipe == 'file'){
            document.getElementById("soal_jawaban_div").innerHTML += `

            <div class="row">
                <div class="col-md-6">
                    <?php if(isset($soal)): ?> 
                    <img src="<?php echo e(asset('images/soal/' .  $soal->soal_a)); ?>" style="height: 250px;">
                    <?php endif; ?>
                    <div class="form-group">
                        <label>Pilihan A</label>
                        <input type="file" class="form-control <?php $__errorArgs = ['soal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_a" id="soal_a" value="<?php echo e(old('soal_a')  ?? ''); ?>">
                    </div>
                    <?php $__errorArgs = ['soal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <?php if(isset($soal)): ?> 
                    <img src="<?php echo e(asset('images/soal/' .  $soal->soal_b)); ?>" style="height: 250px;">
                    <?php endif; ?>
                    <div class="form-group">
                        <label>Pilihan B</label>
                        <input type="file" class="form-control <?php $__errorArgs = ['soal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_b" id="soal_b" value="<?php echo e(old('soal_b')  ?? ''); ?>">
                    </div>
                    <?php $__errorArgs = ['soal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <?php if(isset($soal)): ?> 
                    <img src="<?php echo e(asset('images/soal/' .  $soal->soal_c)); ?>" style="height: 250px;">
                    <?php endif; ?>
                    <div class="form-group">
                        <label>Pilihan C</label>
                        <input type="file" class="form-control <?php $__errorArgs = ['soal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_c" id="soal_c" value="<?php echo e(old('soal_c')  ?? ''); ?>">
                    </div>
                    <?php $__errorArgs = ['soal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <?php if(isset($soal)): ?> 
                    <img src="<?php echo e(asset('images/soal/' .  $soal->soal_d)); ?>" style="height: 250px;">
                    <?php endif; ?>
                    <div class="form-group">
                        <label>Pilihan D</label>
                        <input type="file" class="form-control <?php $__errorArgs = ['soal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_d" id="soal_d" value="<?php echo e(old('soal_d')  ?? ''); ?>">
                    </div>
                    <?php $__errorArgs = ['soal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <?php if(isset($soal)): ?> 
                    <img src="<?php echo e(asset('images/soal/' .  $soal->soal_e)); ?>" style="height: 250px;">
                    <?php endif; ?>
                    <div class="form-group">
                        <label>Pilihan E</label>
                        <input type="file" class="form-control <?php $__errorArgs = ['soal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_e" id="soal_e" value="<?php echo e(old('soal_e')  ?? ''); ?>">
                    </div>
                    <?php $__errorArgs = ['soal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Kunci Jawaban</label>
                        <table class="table table-bordered">
                            <tr>
                                <td>A</td>
                                <td>
                                    <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_a" value="<?php echo e(old('skorsoal_a')  ?? $soal->skorsoal_a ?? ''); ?>">
                                    <?php $__errorArgs = ['skorsoal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>

                            </tr>
                            <tr>
                                <td>B</td>
                                <td>
                                    <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_b" value="<?php echo e(old('skorsoal_b')  ?? $soal->skorsoal_b ?? ''); ?>">
                                    <?php $__errorArgs = ['skorsoal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                            </tr>
                            <tr>
                                <td>C</td>
                                <td>
                                    <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_c"  value="<?php echo e(old('skorsoal_c')  ?? $soal->skorsoal_c ?? ''); ?>">
                                    <?php $__errorArgs = ['skorsoal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                            </tr>
                            <tr>
                                <td>D</td>
                                <td>
                                    <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_d" value="<?php echo e(old('skorsoal_d')  ?? $soal->skorsoal_d ?? ''); ?>">
                                    <?php $__errorArgs = ['skorsoal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                            </tr>
                            <tr>
                                <td>E</td>
                                <td>
                                    <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_e" value="<?php echo e(old('skorsoal_e')  ?? $soal->skorsoal_e ?? ''); ?>">
                                    <?php $__errorArgs = ['skorsoal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            `;
            $('.number').keyup(function (e) { 
                this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');
            });
        }else if(tipe == 'audio'){
            document.getElementById("soal_jawaban_div").innerHTML += `

            <div class="row">
                <div class="col-md-6">
                    <?php if(isset($soal)): ?> 
                    <img src="<?php echo e(asset('upload/audio/' .  $soal->soal_a)); ?>" style="height: 250px;">
                    <?php endif; ?>
                    <div class="form-group">
                        <label>Pilihan A</label>
                        <input type="file" class="form-control <?php $__errorArgs = ['soal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_a" id="soal_a" value="<?php echo e(old('soal_a')  ?? ''); ?>">
                    </div>
                    <?php $__errorArgs = ['soal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <?php if(isset($soal)): ?> 
                    <img src="<?php echo e(asset('upload/audio/' .  $soal->soal_b)); ?>" style="height: 250px;">
                    <?php endif; ?>
                    <div class="form-group">
                        <label>Pilihan B</label>
                        <input type="file" class="form-control <?php $__errorArgs = ['soal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_b" id="soal_b" value="<?php echo e(old('soal_b')  ?? ''); ?>">
                    </div>
                    <?php $__errorArgs = ['soal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <?php if(isset($soal)): ?> 
                    <img src="<?php echo e(asset('upload/audio/' .  $soal->soal_c)); ?>" style="height: 250px;">
                    <?php endif; ?>
                    <div class="form-group">
                        <label>Pilihan C</label>
                        <input type="file" class="form-control <?php $__errorArgs = ['soal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_c" id="soal_c" value="<?php echo e(old('soal_c')  ?? ''); ?>">
                    </div>
                    <?php $__errorArgs = ['soal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <?php if(isset($soal)): ?> 
                    <img src="<?php echo e(asset('upload/audio/' .  $soal->soal_d)); ?>" style="height: 250px;">
                    <?php endif; ?>
                    <div class="form-group">
                        <label>Pilihan D</label>
                        <input type="file" class="form-control <?php $__errorArgs = ['soal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_d" id="soal_d" value="<?php echo e(old('soal_d')  ?? ''); ?>">
                    </div>
                    <?php $__errorArgs = ['soal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <?php if(isset($soal)): ?> 
                    <img src="<?php echo e(asset('upload/audio/' .  $soal->soal_e)); ?>" style="height: 250px;">
                    <?php endif; ?>
                    <div class="form-group">
                        <label>Pilihan E</label>
                        <input type="file" class="form-control <?php $__errorArgs = ['soal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_e" id="soal_e" value="<?php echo e(old('soal_e')  ?? ''); ?>">
                    </div>
                    <?php $__errorArgs = ['soal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Kunci Jawaban</label>
                        <table class="table table-bordered">
                            <tr>
                                <td>A</td>
                                <td>
                                    <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_a" value="<?php echo e(old('skorsoal_a')  ?? $soal->skorsoal_a ?? ''); ?>">
                                    <?php $__errorArgs = ['skorsoal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>

                            </tr>
                            <tr>
                                <td>B</td>
                                <td>
                                    <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_b" value="<?php echo e(old('skorsoal_b')  ?? $soal->skorsoal_b ?? ''); ?>">
                                    <?php $__errorArgs = ['skorsoal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                            </tr>
                            <tr>
                                <td>C</td>
                                <td>
                                    <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_c"  value="<?php echo e(old('skorsoal_c')  ?? $soal->skorsoal_c ?? ''); ?>">
                                    <?php $__errorArgs = ['skorsoal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                            </tr>
                            <tr>
                                <td>D</td>
                                <td>
                                    <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_d" value="<?php echo e(old('skorsoal_d')  ?? $soal->skorsoal_d ?? ''); ?>">
                                    <?php $__errorArgs = ['skorsoal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                            </tr>
                            <tr>
                                <td>E</td>
                                <td>
                                    <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_e" value="<?php echo e(old('skorsoal_e')  ?? $soal->skorsoal_e ?? ''); ?>">
                                    <?php $__errorArgs = ['skorsoal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            `;
            $('.number').keyup(function (e) { 
                this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');
            });
        }
    });

</script>

<?php if(count($errors) > 0): ?>
    <script>
        $(document).ready(function () {
            
            // tampilkan form soal
            var tipe = $('#soal_ujian_tipe').val();
            // document.getElementById("soal_ujian_div").innerHTML = '';
            if(tipe == 'text'){
                document.getElementById("soal_ujian_div").innerHTML += `
                <div class="form-group"> 
                    <label>Soal</label>
                    <textarea class="form-control textarea <?php $__errorArgs = ['soal_ujian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_ujian" id="soal_ujian" rows="10"><?php echo e(old('soal_ujian')  ??  $soal->soal_ujian ?? ''); ?></textarea>
                </div>
                <?php $__errorArgs = ['soal_ujian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>`;

                $('.textarea').summernote({
                    height: 200
                });
            }else if(tipe == 'file'){
                document.getElementById("soal_ujian_div").innerHTML += `
                <?php if(isset($soal)): ?>
                <img src="<?php echo e(asset('images/soal/' . $soal->soal_ujian)); ?>" style="height: 250px;">
                <?php endif; ?> 
                <div class="form-group">
                    <label>Soal</label>
                    <input type="file" class="form-control <?php $__errorArgs = ['soal_ujian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_ujian" id="soal_ujian" value="<?php echo e(old('soal_ujian')  ?? ''); ?>">
                </div>
                <?php $__errorArgs = ['soal_ujian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>`;
            }else if(tipe == 'audio'){
                document.getElementById("soal_ujian_div").innerHTML += `
                <?php if(isset($soal)): ?>
                <img src="<?php echo e(asset('upload/audio/' . $soal->soal_ujian)); ?>" style="height: 250px;">
                <?php endif; ?> 
                <div class="form-group">
                    <label>Soal</label>
                    <input type="file" class="form-control <?php $__errorArgs = ['soal_ujian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_ujian" id="soal_ujian" value="<?php echo e(old('soal_ujian')  ?? ''); ?>">
                </div>
                <?php $__errorArgs = ['soal_ujian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>`;
            }

            // tampilkan form jawaban
            var tipe2 = $('#soal_pilihan_tipe').val()
            // document.getElementById("soal_jawaban_div").innerHTML = '';
            if(tipe2 == 'text'){
                document.getElementById("soal_jawaban_div").innerHTML += ` 

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Pilihan A</label>
                            <textarea class="form-control <?php $__errorArgs = ['soal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_a" id="soal_a" rows="10"><?php echo e(old('soal_a')  ?? $soal->soal_a ?? ''); ?></textarea>
                        </div>
                        <?php $__errorArgs = ['soal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Pilihan B</label>
                            <textarea class="form-control <?php $__errorArgs = ['soal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_b" id="soal_b" rows="10"><?php echo e(old('soal_b')  ?? $soal->soal_b ?? ''); ?></textarea>
                        </div>
                        <?php $__errorArgs = ['soal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Pilihan C</label>
                            <textarea class="form-control <?php $__errorArgs = ['soal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_c" id="soal_c" rows="10"><?php echo e(old('soal_c')  ?? $soal->soal_c ?? ''); ?></textarea>
                        </div>
                        <?php $__errorArgs = ['soal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Pilihan D</label>
                            <textarea class="form-control <?php $__errorArgs = ['soal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_d" id="soal_d" rows="10"><?php echo e(old('soal_d')  ?? $soal->soal_d ?? ''); ?></textarea>
                        </div>
                        <?php $__errorArgs = ['soal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Pilihan E</label>
                            <textarea class="form-control <?php $__errorArgs = ['soal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_e" id="soal_e" rows="10"><?php echo e(old('soal_e')  ?? $soal->soal_e ?? ''); ?></textarea>
                        </div>
                        <?php $__errorArgs = ['soal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Kunci Jawaban</label>
                            <table class="table table-bordered">
                                <tr>
                                    <td>A</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_a" value="<?php echo e(old('skorsoal_a')  ?? $soal->skorsoal_a ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>

                                </tr>
                                <tr>
                                    <td>B</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_b" value="<?php echo e(old('skorsoal_b')  ?? $soal->skorsoal_b ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>C</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_c"  value="<?php echo e(old('skorsoal_c')  ?? $soal->skorsoal_c ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>D</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_d" value="<?php echo e(old('skorsoal_d')  ?? $soal->skorsoal_d ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>E</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_e" value="<?php echo e(old('skorsoal_e')  ?? $soal->skorsoal_e ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>              
                `;

                $('.invalid-feedback').css('display', 'block');

                $('.number').keyup(function (e) { 
                    this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');
                });
            }else if(tipe2 == 'file'){
                document.getElementById("soal_jawaban_div").innerHTML += `

                <div class="row">
                    <div class="col-md-6">
                        <?php if(isset($soal)): ?>
                        <img src="<?php echo e(asset('images/soal/' . $soal->soal_a)); ?>" style="height: 250px;">
                        <?php endif; ?> 
                        <div class="form-group">
                            <label>Pilihan A</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['soal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_a" id="soal_a" value="<?php echo e(old('soal_a')  ?? ''); ?>">
                        </div>
                        <?php $__errorArgs = ['soal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <?php if(isset($soal)): ?>
                        <img src="<?php echo e(asset('images/soal/' . $soal->soal_b)); ?>" style="height: 250px;">
                        <?php endif; ?> 
                        <div class="form-group">
                            <label>Pilihan B</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['soal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_b" id="soal_b" value="<?php echo e(old('soal_b')  ?? ''); ?>">
                        </div>
                        <?php $__errorArgs = ['soal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <?php if(isset($soal)): ?>
                        <img src="<?php echo e(asset('images/soal/' . $soal->soal_c)); ?>" style="height: 250px;">
                        <?php endif; ?> 
                        <div class="form-group">
                            <label>Pilihan C</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['soal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_c" id="soal_c" value="<?php echo e(old('soal_c')  ?? ''); ?>">
                        </div>
                        <?php $__errorArgs = ['soal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <?php if(isset($soal)): ?>
                        <img src="<?php echo e(asset('images/soal/' . $soal->soal_d)); ?>" style="height: 250px;">
                        <?php endif; ?> 
                        <div class="form-group">
                            <label>Pilihan D</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['soal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_d" id="soal_d" value="<?php echo e(old('soal_d')  ?? ''); ?>">
                        </div>
                        <?php $__errorArgs = ['soal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <?php if(isset($soal)): ?>
                        <img src="<?php echo e(asset('images/soal/' . $soal->soal_e)); ?>" style="height: 250px;">
                        <?php endif; ?> 
                        <div class="form-group">
                            <label>Pilihan E</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['soal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_e" id="soal_e" value="<?php echo e(old('soal_e')  ?? ''); ?>">
                        </div>
                        <?php $__errorArgs = ['soal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Kunci Jawaban</label>
                            <table class="table table-bordered">
                                <tr>
                                    <td>A</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_a" value="<?php echo e(old('skorsoal_a')  ?? $soal->skorsoal_a ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>

                                </tr>
                                <tr>
                                    <td>B</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_b" value="<?php echo e(old('skorsoal_b')  ?? $soal->skorsoal_b ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>C</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_c"  value="<?php echo e(old('skorsoal_c')  ?? $soal->skorsoal_c ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>D</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_d" value="<?php echo e(old('skorsoal_d')  ?? $soal->skorsoal_d ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>E</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_e" value="<?php echo e(old('skorsoal_e')  ?? $soal->skorsoal_e ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                `;
                $('.invalid-feedback').css('display', 'block');

                $('.number').keyup(function (e) { 
                    this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');
                });
            }else if(tipe2 == 'audio'){
                document.getElementById("soal_jawaban_div").innerHTML += `

                <div class="row">
                    <div class="col-md-6">
                        <?php if(isset($soal)): ?>
                        <img src="<?php echo e(asset('upload/audio/' . $soal->soal_a)); ?>" style="height: 250px;">
                        <?php endif; ?> 
                        <div class="form-group">
                            <label>Pilihan A</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['soal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_a" id="soal_a" value="<?php echo e(old('soal_a')  ?? ''); ?>">
                        </div>
                        <?php $__errorArgs = ['soal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <?php if(isset($soal)): ?>
                        <img src="<?php echo e(asset('upload/audio/' . $soal->soal_b)); ?>" style="height: 250px;">
                        <?php endif; ?> 
                        <div class="form-group">
                            <label>Pilihan B</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['soal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_b" id="soal_b" value="<?php echo e(old('soal_b')  ?? ''); ?>">
                        </div>
                        <?php $__errorArgs = ['soal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <?php if(isset($soal)): ?>
                        <img src="<?php echo e(asset('upload/audio/' . $soal->soal_c)); ?>" style="height: 250px;">
                        <?php endif; ?> 
                        <div class="form-group">
                            <label>Pilihan C</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['soal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_c" id="soal_c" value="<?php echo e(old('soal_c')  ?? ''); ?>">
                        </div>
                        <?php $__errorArgs = ['soal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <?php if(isset($soal)): ?>
                        <img src="<?php echo e(asset('upload/audio/' . $soal->soal_d)); ?>" style="height: 250px;">
                        <?php endif; ?> 
                        <div class="form-group">
                            <label>Pilihan D</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['soal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_d" id="soal_d" value="<?php echo e(old('soal_d')  ?? ''); ?>">
                        </div>
                        <?php $__errorArgs = ['soal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <?php if(isset($soal)): ?>
                        <img src="<?php echo e(asset('upload/audio/' . $soal->soal_e)); ?>" style="height: 250px;">
                        <?php endif; ?> 
                        <div class="form-group">
                            <label>Pilihan E</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['soal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_e" id="soal_e" value="<?php echo e(old('soal_e')  ?? ''); ?>">
                        </div>
                        <?php $__errorArgs = ['soal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Kunci Jawaban</label>
                            <table class="table table-bordered">
                                <tr>
                                    <td>A</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_a" value="<?php echo e(old('skorsoal_a')  ?? $soal->skorsoal_a ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>

                                </tr>
                                <tr>
                                    <td>B</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_b" value="<?php echo e(old('skorsoal_b')  ?? $soal->skorsoal_b ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>C</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_c"  value="<?php echo e(old('skorsoal_c')  ?? $soal->skorsoal_c ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>D</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_d" value="<?php echo e(old('skorsoal_d')  ?? $soal->skorsoal_d ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>E</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_e" value="<?php echo e(old('skorsoal_e')  ?? $soal->skorsoal_e ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                `;
                $('.invalid-feedback').css('display', 'block');

                $('.number').keyup(function (e) { 
                    this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');
                });
            }

        });
    </script>
<?php elseif(isset($soal)): ?>
    <script>
        $(document).ready(function () {
            let id_kategori = $('#soal_kategori_id').val();
            if(id_kategori == '1'){
                $('#soal_mapel_id_div').attr('style', 'display : block');
                $('#soal_submapel_id_div').attr('style', 'display : block');
            }else{
                $('#soal_mapel_id_div').attr('style', 'display: none');
                $('#soal_submapel_id_div').attr('style', 'display: none');
            }


            // tampilkan form soal
            var tipe = $('#soal_ujian_tipe').val();
            // document.getElementById("soal_ujian_div").innerHTML = '';
            if(tipe == 'text'){
                document.getElementById("soal_ujian_div").innerHTML += `
                <div class="form-group"> 
                    <label>Soal</label>
                    <textarea class="form-control textarea <?php $__errorArgs = ['soal_ujian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_ujian" id="soal_ujian" rows="10"><?php echo e(old('soal_ujian')  ??  $soal->soal_ujian ?? ''); ?></textarea>
                </div>
                <?php $__errorArgs = ['soal_ujian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>`;

                $('.textarea').summernote({
                    height: 200
                });
            }else if(tipe == 'file'){
                document.getElementById("soal_ujian_div").innerHTML += ` 
                <img src="<?php echo e(asset('images/soal/' . $soal->soal_ujian)); ?>" style="height: 250px;">
                <div class="form-group">
                    <label>Soal</label>
                    <input type="file" class="form-control <?php $__errorArgs = ['soal_ujian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_ujian" id="soal_ujian" value="<?php echo e(old('soal_ujian')  ?? ''); ?>">
                </div>
                <?php $__errorArgs = ['soal_ujian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>`;
            }else if(tipe == 'audio'){
                document.getElementById("soal_ujian_div").innerHTML += ` 
                <img src="<?php echo e(asset('upload/audio/' . $soal->soal_ujian)); ?>" style="height: 250px;">
                <div class="form-group">
                    <label>Soal</label>
                    <input type="file" class="form-control <?php $__errorArgs = ['soal_ujian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_ujian" id="soal_ujian" value="<?php echo e(old('soal_ujian')  ?? ''); ?>">
                </div>
                <?php $__errorArgs = ['soal_ujian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>`;
            }

            // tampilkan form jawaban
            var tipe2 = $('#soal_pilihan_tipe').val()
            // document.getElementById("soal_jawaban_div").innerHTML = '';
            if(tipe2 == 'text'){
                document.getElementById("soal_jawaban_div").innerHTML += ` 

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Pilihan A</label>
                            <textarea class="form-control <?php $__errorArgs = ['soal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_a" id="soal_a" rows="10"><?php echo e(old('soal_a')  ?? $soal->soal_a ?? ''); ?></textarea>
                        </div>
                        <?php $__errorArgs = ['soal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Pilihan B</label>
                            <textarea class="form-control <?php $__errorArgs = ['soal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_b" id="soal_b" rows="10"><?php echo e(old('soal_b')  ?? $soal->soal_b ?? ''); ?></textarea>
                        </div>
                        <?php $__errorArgs = ['soal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Pilihan C</label>
                            <textarea class="form-control <?php $__errorArgs = ['soal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_c" id="soal_c" rows="10"><?php echo e(old('soal_c')  ?? $soal->soal_c ?? ''); ?></textarea>
                        </div>
                        <?php $__errorArgs = ['soal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Pilihan D</label>
                            <textarea class="form-control <?php $__errorArgs = ['soal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_d" id="soal_d" rows="10"><?php echo e(old('soal_d')  ?? $soal->soal_d ?? ''); ?></textarea>
                        </div>
                        <?php $__errorArgs = ['soal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Pilihan E</label>
                            <textarea class="form-control <?php $__errorArgs = ['soal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_e" id="soal_e" rows="10"><?php echo e(old('soal_e')  ?? $soal->soal_e ?? ''); ?></textarea>
                        </div>
                        <?php $__errorArgs = ['soal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Kunci Jawaban</label>
                            <table class="table table-bordered">
                                <tr>
                                    <td>A</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_a" value="<?php echo e(old('skorsoal_a')  ?? $soal->skorsoal_a ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>

                                </tr>
                                <tr>
                                    <td>B</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_b" value="<?php echo e(old('skorsoal_b')  ?? $soal->skorsoal_b ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>C</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_c"  value="<?php echo e(old('skorsoal_c')  ?? $soal->skorsoal_c ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>D</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_d" value="<?php echo e(old('skorsoal_d')  ?? $soal->skorsoal_d ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>E</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_e" value="<?php echo e(old('skorsoal_e')  ?? $soal->skorsoal_e ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>                
                `;

                $('.invalid-feedback').css('display', 'block');

                $('.number').keyup(function (e) { 
                    this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');
                });
            }else if(tipe2 == 'file'){
                document.getElementById("soal_jawaban_div").innerHTML += `

                <div class="row">
                    <div class="col-md-6">
                        <img src="<?php echo e(asset('images/soal/' . $soal->soal_a)); ?>" style="height: 250px;">
                        <div class="form-group">
                            <label>Pilihan A</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['soal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_a" id="soal_a" value="<?php echo e(old('soal_a')  ?? ''); ?>">
                        </div>
                        <?php $__errorArgs = ['soal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <img src="<?php echo e(asset('images/soal/' . $soal->soal_b)); ?>" style="height: 250px;">
                        <div class="form-group">
                            <label>Pilihan B</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['soal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_b" id="soal_b" value="<?php echo e(old('soal_b')  ?? ''); ?>">
                        </div>
                        <?php $__errorArgs = ['soal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <img src="<?php echo e(asset('images/soal/' . $soal->soal_c)); ?>" style="height: 250px;">
                        <div class="form-group">
                            <label>Pilihan C</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['soal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_c" id="soal_c" value="<?php echo e(old('soal_c')  ?? ''); ?>">
                        </div>
                        <?php $__errorArgs = ['soal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <img src="<?php echo e(asset('images/soal/' . $soal->soal_d)); ?>" style="height: 250px;">
                        <div class="form-group">
                            <label>Pilihan D</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['soal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_d" id="soal_d" value="<?php echo e(old('soal_d')  ?? ''); ?>">
                        </div>
                        <?php $__errorArgs = ['soal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <img src="<?php echo e(asset('images/soal/' . $soal->soal_e)); ?>" style="height: 250px;">
                        <div class="form-group">
                            <label>Pilihan E</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['soal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_e" id="soal_e" value="<?php echo e(old('soal_e')  ?? ''); ?>">
                        </div>
                        <?php $__errorArgs = ['soal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Kunci Jawaban</label>
                            <table class="table table-bordered">
                                <tr>
                                    <td>A</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_a" value="<?php echo e(old('skorsoal_a')  ?? $soal->skorsoal_a ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>

                                </tr>
                                <tr>
                                    <td>B</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_b" value="<?php echo e(old('skorsoal_b')  ?? $soal->skorsoal_b ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>C</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_c"  value="<?php echo e(old('skorsoal_c')  ?? $soal->skorsoal_c ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>D</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_d" value="<?php echo e(old('skorsoal_d')  ?? $soal->skorsoal_d ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>E</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_e" value="<?php echo e(old('skorsoal_e')  ?? $soal->skorsoal_e ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                `;
                $('.invalid-feedback').css('display', 'block');

                $('.number').keyup(function (e) { 
                    this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');
                });
            }else if(tipe2 == 'audio'){
                document.getElementById("soal_jawaban_div").innerHTML += `

                <div class="row">
                    <div class="col-md-6">
                        <img src="<?php echo e(asset('upload/audio/' . $soal->soal_a)); ?>" style="height: 250px;">
                        <div class="form-group">
                            <label>Pilihan A</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['soal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_a" id="soal_a" value="<?php echo e(old('soal_a')  ?? ''); ?>">
                        </div>
                        <?php $__errorArgs = ['soal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <img src="<?php echo e(asset('upload/audio/' . $soal->soal_b)); ?>" style="height: 250px;">
                        <div class="form-group">
                            <label>Pilihan B</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['soal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_b" id="soal_b" value="<?php echo e(old('soal_b')  ?? ''); ?>">
                        </div>
                        <?php $__errorArgs = ['soal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <img src="<?php echo e(asset('upload/audio/' . $soal->soal_c)); ?>" style="height: 250px;">
                        <div class="form-group">
                            <label>Pilihan C</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['soal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_c" id="soal_c" value="<?php echo e(old('soal_c')  ?? ''); ?>">
                        </div>
                        <?php $__errorArgs = ['soal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <img src="<?php echo e(asset('upload/audio/' . $soal->soal_d)); ?>" style="height: 250px;">
                        <div class="form-group">
                            <label>Pilihan D</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['soal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_d" id="soal_d" value="<?php echo e(old('soal_d')  ?? ''); ?>">
                        </div>
                        <?php $__errorArgs = ['soal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <img src="<?php echo e(asset('upload/audio/' . $soal->soal_e)); ?>" style="height: 250px;">
                        <div class="form-group">
                            <label>Pilihan E</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['soal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="soal_e" id="soal_e" value="<?php echo e(old('soal_e')  ?? ''); ?>">
                        </div>
                        <?php $__errorArgs = ['soal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Kunci Jawaban</label>
                            <table class="table table-bordered">
                                <tr>
                                    <td>A</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_a" value="<?php echo e(old('skorsoal_a')  ?? $soal->skorsoal_a ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>

                                </tr>
                                <tr>
                                    <td>B</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_b" value="<?php echo e(old('skorsoal_b')  ?? $soal->skorsoal_b ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_b'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>C</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_c"  value="<?php echo e(old('skorsoal_c')  ?? $soal->skorsoal_c ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_c'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>D</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_d" value="<?php echo e(old('skorsoal_d')  ?? $soal->skorsoal_d ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>E</td>
                                    <td>
                                        <input type="text" class="form-control number <?php $__errorArgs = ['skorsoal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan bobot" name="skorsoal_e" value="<?php echo e(old('skorsoal_e')  ?? $soal->skorsoal_e ?? ''); ?>">
                                        <?php $__errorArgs = ['skorsoal_e'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                `;
                $('.invalid-feedback').css('display', 'block');

                $('.number').keyup(function (e) { 
                    this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');
                });
            }

        });
    </script>
<?php endif; ?>

<!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend/layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\skd\resources\views/backend/pages/soal/form.blade.php ENDPATH**/ ?>