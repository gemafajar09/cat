<!-- jQuery -->
<script src="<?php echo e(asset('/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('/dist/js/adminlte.min.js')); ?>"></script><?php /**PATH D:\www\skd\resources\views/template/script.blade.php ENDPATH**/ ?>