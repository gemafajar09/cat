<link rel="stylesheet" href="<?php echo e(asset('/plugins/fontawesome-free/css/all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/dist/css/adminlte.min.css')); ?>">
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet"><?php /**PATH D:\www\skd\resources\views/backend/header.blade.php ENDPATH**/ ?>