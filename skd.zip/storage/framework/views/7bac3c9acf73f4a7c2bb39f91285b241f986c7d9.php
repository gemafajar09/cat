
<?php $__env->startSection('content'); ?>
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>Token Ujian</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="#">MEDIATAMA CAT</a></li>
                                <li class="breadcrumb-item active">Token Ujian</li>
                            </ol>
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <!-- Default box -->
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><a class="btn btn-primary btn-sm text-white" href="<?php echo e(route('token.create')); ?>"><i class="fa fa-plus"></i> Add</a></h3>
                                    <div class="card-tools">
                                        <button type="button" class="btn btn-tool" data-card-widget="collapse"
                                            data-toggle="tooltip" title="Collapse">
                                            <i class="fas fa-minus"></i></button>
                                        <button type="button" class="btn btn-tool" data-card-widget="remove"
                                            data-toggle="tooltip" title="Remove">
                                            <i class="fas fa-times"></i></button>
                                    </div>
                                </div>
                                <div class="card-body">
                                
                                    <div class="callout callout-success" style="display:none" id="message">
                                        <strong><?php echo e(session()->get('message')); ?></strong>
                                        <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
                                    </div>

                                    <table id="example1" class="table table-bordered table-striped example1">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Tanggal</th>
                                                <th>Jam Mulai</th>
                                                <th>Jam Selesai</th>
                                                <th>Token</th>
                                                <th>Option</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $token; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $tkn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($no+1); ?></td>
                                                <td><?php echo e(\Carbon\Carbon::parse($tkn->token_tanggal)->isoFormat('D MMMM Y')); ?></td>
                                                <td><?php echo e($tkn->token_jam_mulai); ?></td>
                                                <td><?php echo e($tkn->token_jam_selesai); ?></td>
                                                <td><?php echo e($tkn->token_key); ?></td>
                                                <td>
                                                    <button class="btn btn-success btn-sm" onclick="mSetting('<?php echo e($tkn->token_id); ?>')"><i class="fa fa-cog"></i> Setting Soal</button>
                                                    <a href="<?php echo e(route('token.edit', $tkn->token_id)); ?>" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></a>
                                                    <button type="button" class="btn btn-danger btn-sm" onclick="mHapus('<?php echo e(route('token.delete', $tkn->token_id)); ?>')"><i class="fa fa-trash"></i> </button>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <!-- /.card-body -->
                                <div class="card-footer">
                                    
                                </div>
                                <!-- /.card-footer-->
                            </div>
                            <!-- /.card -->
                        </div>
                    </div>
                </div>
            </section>
            <!-- /.content -->

            <!-- modal hapus -->
            <div class="modal fade" id="ModalHapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Hapus Data</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="" method="POST" id="formDelete">
                            <div class="modal-body">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                Yakin Hapus Data ?
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-info btn-sm">Delete</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


            <!-- modal setting soal -->
            <div class="modal fade" id="ModalSetting" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Setting Soal</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="card">
                                <div class="card-header">
                                    Tambah Data Soal
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <input type="hidden" id="token_id">
                                        <?php $__currentLoopData = $kategorisoal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $ktg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Kategori Soal</label>
                                                    <input type="hidden" value="<?php echo e($ktg->kategori_id); ?>" name="kategori_id" class="form-control">
                                                    <input type="text" value="<?php echo e($ktg->kategori_soal); ?>" class="form-control" readonly>
                                                </div>
                                            </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Jumlah Soal</label>
                                                <input type="text" id="setting_soal_jumlah<?= $no+1 ?>" name="setting_soal_jumlah" class="form-control number">
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <button onclick="simpanSoal()" class="btn btn-primary btn-block">Save</button>

                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>

            <script>
                // untuk hapus data
                function mHapus(url) {
                    $('#ModalHapus').modal()
                    $('#formDelete').attr('action', url);
                }
                // utk setting soal
                function mSetting(id) {
                    $('#token_id').val(id);

                    $.ajax({
                        type: "GET",
                        url: "<?php echo e(url('/cat-admin/setting-soal')); ?>/" + id,
                        headers: {
                            'X-CSRF-Token': '<?php echo e(csrf_token()); ?>',
                        },
                        dataType: "JSON",
                        success: function (response) {
                            if(response.data){
                                var setting_soal_jumlah = response.data.setting_soal_jumlah;
                                var a = setting_soal_jumlah.split(",");
                                
                                for (let i = 0; i < $('input[name*=setting_soal_jumlah').length; i++) {
                                    $(`#setting_soal_jumlah${i + 1}`).val(a[i]);
                                }
                            }

                        }
                    });

                    $('#ModalSetting').modal()
                }

                // simpan setting soal
                function simpanSoal() {  
                    var kategori_id = $('input[name^=kategori_id]').map(function(idx, elem) {
                        return $(elem).val();
                    }).get();
                    
                    var setting_soal_jumlah = $('input[name^=setting_soal_jumlah]').map(function(idx, elem) {
                        return $(elem).val();
                    }).get();

                    var token_id = $('#token_id').val();

                    $.ajax({
                        type: "POST",
                        url: "<?php echo e(route('setting-soal.store')); ?>",
                        data: {
                            "_token" : "<?php echo e(csrf_token()); ?>",
                            "token_id" : token_id,
                            "kategori_id" : kategori_id,
                            "setting_soal_jumlah" : setting_soal_jumlah,
                        },
                        dataType: "JSON",
                        success: function (response) {
                            console.log(response.message);
                        }
                    });
                }


            </script>

            <?php if(session()->has('message')): ?>
            <script>
                $('#message').show();
                setInterval(function(){ $('#message').hide(); }, 5000);
            </script>
            <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend/layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\skd\resources\views/backend/pages/token/index.blade.php ENDPATH**/ ?>