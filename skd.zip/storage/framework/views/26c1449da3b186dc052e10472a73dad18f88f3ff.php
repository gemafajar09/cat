<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <title>Selamat Ujian</title>

    <?php echo $__env->make('frontend/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('frontend/script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
    <?php if(session('pesan') == true): ?>
        <script>
            toast.success('<?= session('pesan') ?>')
        </script>
    <?php endif; ?>
    <?php if(session('error') == true): ?>
        <script>
            toast.error('<?= session('error') ?>')
        </script>
    <?php endif; ?>
    <div class="row">  
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>

</html>
<?php /**PATH D:\www\skd\resources\views/frontend/index.blade.php ENDPATH**/ ?>