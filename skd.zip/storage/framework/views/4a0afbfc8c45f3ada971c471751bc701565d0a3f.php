<div>
    <p>
        <h3>TWK <hr></h3>
        <h5>
            1.  Semua siswa SMAN 1 Yogyakarta mengikuti upacara bendera. Nana siswa SMAN 1 Yogyakarta. Jadi...
        </h5>
    </p>
    <input type="radio" name="pilihan"> A. Belum tentu Nana mengikuti upacara bendera 
    <br>
    <input type="radio" name="pilihan"> B. Nana tidak mengikuti upacara bendera
    <br>
    <input type="radio" name="pilihan"> C. Nana mungkin mengikuti upacara bendera
    <br>
    <input type="radio" name="pilihan"> D. Nana mengikuti upacara bendera
    <br>
    <input type="radio" name="pilihan"> E. Tidak dapat ditarik kesimpulan
</div>
<div class="raguragu" style="margin-bottom:1em;">
    <input type="checkbox"> Ragu-Ragu
</div><?php /**PATH D:\www\skd\resources\views/frontend/page/ujian/isisoal2.blade.php ENDPATH**/ ?>