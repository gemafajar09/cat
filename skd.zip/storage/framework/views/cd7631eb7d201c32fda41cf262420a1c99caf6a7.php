<link rel="stylesheet" href="<?php echo e(asset('/css/w3.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/app.css')); ?>">
<!-- <script type="text/javascript" src="<?php echo e(asset('/js/app.js')); ?>"></script> -->
<link rel="stylesheet" href="<?php echo e(asset('/frontend/font-awesome/css/font-awesome.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/style.css')); ?>">
<script src="<?php echo e(asset('/js/sweetalert.min.js')); ?>"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<?php /**PATH D:\www\skd\resources\views/frontend/header.blade.php ENDPATH**/ ?>