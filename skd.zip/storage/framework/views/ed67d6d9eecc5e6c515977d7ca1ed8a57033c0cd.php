
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <?php echo $__env->make('frontend/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="container py-5">
    <div class="row">
        <div class="col-md-8">
            <div class="card card-default">
                <div class="card-header bg-primary text-white">
                    Data Peserta
                </div>
                <div class="card-body">
                    <label for="">Nama</label>
                    <input type="text" readonly value="<?php echo e(session('user_nama')); ?>" class="form-control">
                    <label for="">NIK</label>
                    <input type="text" readonly value="<?php echo e(session('user_nik')); ?>" class="form-control">
                    <label for="">Durasi</label>
                    <input type="text" readonly value="120 Menit" class="form-control">
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-default">
                <div class="card-header bg-primary text-white">
                    Mulai Ujian
                </div>
                <div class="card-body">
                    <div class="alert alert-primary">
                        <p>Silahkan Masukan Token Ujian Untuk Memulai Ujian</p>
                    </div>
                    <form action="<?php echo e(route('ujian-mulai')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <input type="text" name="token" class="form-control" placeholder="Inputkan Token">
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if(session('pesan') == true): ?>
    <script>
        toast.success('<?= session('pesan') ?>')
    </script>
<?php endif; ?>
<?php if(session('error') == true): ?>
    <script>
        toast.error('<?= session('error') ?>')
    </script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\skd\resources\views/frontend/page/login/aktiftoken.blade.php ENDPATH**/ ?>