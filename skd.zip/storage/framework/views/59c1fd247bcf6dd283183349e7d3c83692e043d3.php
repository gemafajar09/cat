<div id="myNav" class="overlay w3-card-4">

  <header >
    <a href="javascript:void(0)" class="w3-btn w3-block w3-aqua" onclick="closeNav()"><i style="color:white" class="fa fa-arrow-right"></i></a>
  </header>

  <div class="overlay-content" >
    <div class="container">
        <div class="row">
        <div class="col-md-12" >
          <br>
        <div class="container-fluid">
          <div class="row"  >
              <?php $__currentLoopData = $soal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-md-3" style="margin-top:15px;  padding-right: 5px;padding-left: 5px;">
                      <a id="<?php echo e($a); ?>" style="background-color:aqua; color:white" class="w3-button w3-round w3-padding-large" role="button" onclick="isisoal('<?php echo e($a); ?>')"><b><?php echo e($i+1); ?></b></a><span class="w3-badge badge-style  w3-white" ><b id="jawabanSoal<?php echo e($a); ?>"></b></span>
                  </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>   
        </div>
        <br><br>
        </div>

      </div>
    </div>
  </div>
</div><?php /**PATH D:\www\skd\resources\views/frontend/page/ujian/listsoal.blade.php ENDPATH**/ ?>