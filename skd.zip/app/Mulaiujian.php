<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mulaiujian extends Model
{
    //
}
