<link rel="stylesheet" href="{{ asset('/css/w3.css') }}">
<link rel="stylesheet" type="text/css" href="{{asset('/css/app.css')}}">
<!-- <script type="text/javascript" src="{{asset('/js/app.js')}}"></script> -->
<link rel="stylesheet" href="{{asset('/frontend/font-awesome/css/font-awesome.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('/css/style.css')}}">
<script src="{{asset('/js/sweetalert.min.js')}}"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
