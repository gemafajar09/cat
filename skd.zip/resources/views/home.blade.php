@extends('frontend/index')

@section('content')
<div class="col-md-12">
    <h3>welcome</h3>
</div>
@endsection